<?php
session_start();
if(isset($_SESSION["kullanici_adi"])){
    echo "<h3>Öğretmen Sayfası</h3>";
    echo "<h3>".$_SESSION["kullanici_adi"]." HOŞGELDİNİZ</h3>";
}
else{
    echo "Bu sayfayı görüntüleme yetkiniz yoktur.";
    exit();
}
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ana Sayfa</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
      ul{
    list-style-type: none;
    margin: 80px 30px 0px;
    padding: 0px;
    width: 200px;
    background-color: bisque;
    height: 70px;
    
}
li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
    background-color: bisque;
}
.active{
    background-color: #04AA6D;
  color: white;
}
li {
    text-align: center;
    
}
   
li a.active {
    background-color: #04AA6D;
    color: white;
}
  
li a:hover:not(.active) {
    background-color:lightgreen;
    color: white;
} 
.square{
    width: 1000px;
    height: 600px;
    background-color: white;
    margin-left: 300px;
    margin-top: -200px;
}
.exam{
    width: 500px;
    height: 300px;
    background-color:#04AA6D;
    margin-left: 300px;
    margin-top: -600px;
}
.question{
    width: 500px;
    height: 300px;
    background-color: #04AA6D;
    margin-left: 820px;
    margin-top: -300px;
}
.delete{
    width: 500px;
    height: 300px;
    background-color:#04AA6D;
    margin-left: 300px;
    margin-top: 50px;
}
.displayexam{
    width: 500px;
    height: 300px;
    background-color:#04AA6D;
    margin-left: 820px;
    margin-top: -300px;
}
.btnexam{
    width: 300px;
    height: 50px;
    margin: 30px 100px;
    background-color: white;
    align-items: center;
    border: 5px solid #04AA6D;
    border-radius: 50px;
}
.btndisp{
    width: 300px;
    height: 50px;
    margin: 30px 100px;
    background-color: white;
    align-items: center;
    border: 5px solid #04AA6D;
    border-radius: 50px;
}
.bx{
    color :white;
    font-size: 100px;
    margin: 50px 200px;
}
.btnq{
    width: 300px;
    height: 50px;
    margin: 30px 100px;
    background-color: white;
    align-items: center;
    border: 5px solid #04AA6D;
    border-radius: 50px;
}
.btndel{
    width: 300px;
    height: 50px;
    margin: 30px 100px;
    background-color: white;
    align-items: center;
    border: 5px solid #04AA6D;
    border-radius: 50px;
}

    </style>
</head>
<body>
      <ul>
        <li><a class="active" href="maint.php">Ana Sayfa</a></li>
        <li><a class="addexam" href="addexam.php">Sınav Ekle</a></li>
        <li><a class="addque" href="addque.php">Soru Ekle</a></li>
        <li><a class="delexam" href="delexam.php">Sınav Sil</a></li>
        <li><a class="exams" href="exams.php">Aktif Sınavlar</a></li>
        <li><a href="cikis.php">Çıkış Yap</a></li>
      </ul>

    <div class="square">
      
    </div>  
    <div class="exam">

      <i class='bx bxs-plus-circle'></i>
      <form action="addexam.php">
        <button type="submit" class="btnexam">
          Sınav Ekle
        </button>
        
      </form>
    </div>
    <div class="question">
      <i class='bx bxs-plus-circle'></i>
      <form action="addque.php">
        <button type="submit" class="btnq">
          Soru Ekle
        </button>
      </form>
    </div>
    <div class="delete">
      <i class='bx bx-trash'></i>
      <form action="delque.php">
        <button type="submit" class="btndel">
          Sınav Sil
        </button>
      </form>
    </div>
    <div class="displayexam">
      <i class='bx bx-list-ul'></i>
      <form action="exams.php">
        <button type="submit" class="btndisp">
          Aktif Sınavlar
        </button>
      </form>
    </div>
    
</body>
</html>