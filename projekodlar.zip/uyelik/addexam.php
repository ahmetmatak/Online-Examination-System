<?php

include("baglanti.php");
date_default_timezone_set('Europe/Istanbul'); 

if(isset($_POST['sinavAdi'])&&($_POST['soruSayisi'])&&($_POST['baslamaSaati'])&&($_POST['bitisSaati'])){
    $sinavAdi = $_POST['sinavAdi'];
    $soruSayisi = $_POST['soruSayisi'];
    $baslamaSaati=$_POST['baslamaSaati'];
    $bitisSaati=$_POST['bitisSaati'];
    $sql = "INSERT INTO sinavlar (sinav_adi, soru_sayisi, baslama_saati, bitis_saati) VALUES ('$sinavAdi', '$soruSayisi', '$baslamaSaati', '$bitisSaati')";

    if ($baglanti->query($sql) === TRUE) {
        echo "Yeni sınav başarıyla eklendi.";
        
    } else {
        echo "Sınav ekleme hatası: " . $baglanti->error;
    }

}

$baglanti->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Sınav Ekleme Formu</title>
    <style>
        .btn{
            width: 162px;
            margin: 10px 0px;
        }
        ul{
    list-style-type: none;
    margin: 80px 30px 0px;
    padding: 0px;
    width: 200px;
    background-color: bisque;
    height: 70px;
    
}
li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
    background-color: bisque;
}
.active{
    background-color: #04AA6D;
  color: white;
}
li {
    text-align: center;
    
}
   
li a.active {
    background-color: #04AA6D;
    color: white;
}
  
li a:hover:not(.active) {
    background-color:lightgreen;
    color: white;
} 
.form{
    margin: -100px 400px;
}
    </style>
</head>
<body>
        <ul>
            <li><a class="main" href="maint.php">Ana Sayfa</a></li>
            <li><a class="active" href="addexam.php">Sınav Ekle</a></li>
            <li><a class="addque" href="addque.php">Soru Ekle</a></li>
            <li><a class="delexam" href="delexam.php">Sınav Sil</a></li>
            <li><a class="exams" href="exams.php">Aktif Sınavlar</a></li>
            <li><a href="cikis.php">Çıkış Yap</a></li>
        </ul>
    
    <div class="form">
    <h2>Sınav Ekleme Formu</h2>
    <form action="addexam.php" method="POST">
        <label for="sinavAdi">Sınav Adı:</label><br>
        <input type="text" id="sinavAdi" name="sinavAdi"><br><br>

        <label for="soruSayisi">Soru Sayısı:</label><br>
        <input type="number" id="soruSayisi" name="soruSayisi" min="1"><br><br>

        <label for="baslamaSaati">Sınav Başlama Saati:</label><br>
        <input type="datetime-local" name="baslamaSaati" id="baslamaSaati"><br><br>

        <label for="bitisSaati">Sınav Bitiş Saati:</label><br>
        <input type="datetime-local" name="bitisSaati" id="bitisSaati"><br>

        <input type="submit" class="btn" value="Sınav Ekle">
    </form>
    </div>
</body>
</html>
