<?php
include("baglanti.php");
 $sql = "SELECT sinav_adi, soru_sayisi, baslama_saati, bitis_saati FROM sinavlar";
 $sonuc = $baglanti->query($sql);

 if ($sonuc->num_rows > 0) {
     $sayac = 0; 
     while ($row = $sonuc->fetch_assoc()) {
         $sayac++;
         echo "<div class='form'>";
         echo "<b>Aktif Sınav<b><br>";
         echo "<hr>";   
         echo "Sınav Adı: " . $row["sinav_adi"] . "<br>";
         echo "Soru Sayısı: " . $row["soru_sayisi"] . "<br>";
         echo "Sınav Başlama Saati: " . $row["baslama_saati"] . "<br>";
         echo "Sınav Bitiş Saati: " . $row["bitis_saati"] . "<br>";
         echo "<form action='sinav_detay.php' method='post'>";
         echo "<input type='hidden' name='sinav_adi' value='" . $row["sinav_adi"] . "'>";
         echo "</form>";
         echo "<hr>"; 
         echo "</div>";
         
         if ($sayac % 3 === 0 && $sayac !== $sonuc->num_rows) {
             echo "<hr>";
         }
     }
 } else {
     echo "Veritabanında hiç sınav bulunamadı.";
 }
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktif Sınavlar</title>
    <style>
        
        ul{
    list-style-type: none;
    margin: -100px 30px;
    padding: 0px;
    width: 200px;
    background-color: bisque;
    height: 70px;

    
}
li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
    background-color: bisque;
}
.active{
    background-color: #04AA6D;
  color: white;
}
li {
    text-align: center;
    
}
   
li a.active {
    background-color: #04AA6D;
    color: white;
}
  
li a:hover:not(.active) {
    background-color:lightgreen;
    color: white;
}   
.form{
    margin: 50px 400px;
}
    </style>
</head>
<body>
    <ul>
        <li><a class="main" href="maint.php">Ana Sayfa</a></li>
        <li><a class="addexam" href="addexam.php">Sınav Ekle</a></li>
        <li><a class="addque" href="addque.php">Soru Ekle</a></li>
        <li><a class="delexam" href="delexam.php">Sınav Sil</a></li>
        <li><a class="active" href="exams.php">Aktif Sınavlar</a></li>
        <li><a href="cikis.php">Çıkış Yap</a></li>
    </ul>
</body>
</html>