<?php
include("baglanti.php");
session_start();
echo "<title>Ana Sayfa</title>";
if(isset($_SESSION["kullanici_adi"])){
    echo "<h3>Öğrenci Sayfası</h3>";
    echo "<h3>".$_SESSION["kullanici_adi"]." HOŞGELDİNİZ</h3>";
    $sql = "SELECT sinav_adi, soru_sayisi, baslama_saati, bitis_saati FROM sinavlar";
    $sonuc = $baglanti->query($sql);

    if ($sonuc->num_rows > 0) {
        $sayac = 0; 
        echo "<hr>"; 
        while ($row = $sonuc->fetch_assoc()) {
            $sayac++;
            echo "<div class='card'>";
            echo "<br>";
            echo "Sınav Adı: " . $row["sinav_adi"] . "<br>";
            echo "Soru Sayısı: " . $row["soru_sayisi"] . "<br>";
            echo "Sınav Başlama Saati: " . $row["baslama_saati"] . "<br>";
            echo "Sınav Bitiş Saati: " . $row["bitis_saati"] . "<br>";
            echo "<form action='sinav_detay.php' method='post'>";
            echo "<input type='hidden' name='sinav_adi' value='" . $row["sinav_adi"] . "'>";
            echo "<input type='submit' class='btn' value='Sınava Gir'>";
            echo "</form>";
            echo "<hr>"; 
            echo "</div>";
            if ($sayac % 3 === 0 && $sayac !== $sonuc->num_rows) {
                echo "<hr>";
            }
        }
    } else {
        echo "Veritabanında hiç sınav bulunamadı.";
    }
} else {
    echo "Bu sayfayı görüntüleme yetkiniz yoktur.";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ana Sayfa</title>
    <style>
ul{
    list-style-type: none;
    margin: 300px 30px 0px;
    padding: 0px;
    width: 200px;
    background-color: bisque;
    height: 70px;   
}
li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
}

li {
    text-align: center;
    
}
   
li a.active {
    background-color: #04AA6D;
    color: white;
}
  
li a:hover:not(.active) {
    background-color:lightgreen;
    color: white;
} 


.square{
    width: 1000px;
    height: 600px;
    background-color: white;
    margin-left: 300px;
    margin-top: -300px;
}
.card{
    margin-left: 300px;
}
.menu{
    margin: -170px 0px;
}
.btn{
    margin:-50px 320px;
}
    </style>
</head>
<body>
    <div class="menu">
      <ul>
        <li><a class="active" href="mains.php">Ana Sayfa</a></li>
        <li><a href="cikis.php">Çıkış Yap</a></li>
      </ul>
    </div>
</body>
</html>

