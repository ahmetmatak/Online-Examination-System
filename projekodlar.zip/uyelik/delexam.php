<?php

include("baglanti.php");
if(isset($_POST['sinav_adi'])){
    $sinavadi=$_POST['sinav_adi'];
    $sil="DELETE FROM sinavlar WHERE sinav_adi = '$sinavadi'";
    if ($baglanti->query($sil) === TRUE) {
        echo "Sınav başarıyla silindi.";
    } else {
        echo "Sınav silinirken bir hata oluştu: " . $baglanti->error;
    }
}

?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sınav Sil</title>
    <style>
         .form{
            margin:-100px 400px;
        }
        .btn{
            width: 170px;
            margin: 10px 0px;
        }
        ul{
    list-style-type: none;
    margin: 80px 30px 0px;
    padding: 0px;
    width: 200px;
    background-color: bisque;
    height: 70px;
    
}
li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
    background-color: bisque;
}
li {
    text-align: center;
    
}
.active {
  background-color: #04AA6D;
  color: white;
}
li a.active {
    background-color: #04AA6D;
    color: white;
}
  
li a:hover:not(.active) {
    background-color:lightgreen;
    color: white;
} 
    </style>
</head>
<body>
        <ul>
            <li><a class="main" href="maint.php">Ana Sayfa</a></li>
            <li><a class="addexam" href="addexam.php">Sınav Ekle</a></li>
            <li><a class="addque" href="addque.php">Soru Ekle</a></li>
            <li><a class="active" href="delexam.php">Sınav Sil</a></li>
            <li><a class="exams" href="exams.php">Aktif Sınavlar</a></li>
            <li><a href="cikis.php">Çıkış Yap</a></li>
        </ul>
    <div class="form">
        <h2>Sınav Silme Formu</h2>
        <form action="delexam.php" method="POST">
        <label for="sinav_adi">Silmek istediğiniz sınavın adı: </label>
        <input type="text" id="sinav_adi" name="sinav_adi" required><br>

        <input type="submit" class="btn" value="Sınavı Sil">
    </form>
    </div>
    
    
</body>
</html>


