<?php
    include("baglanti.php");
    $username_err=$email_err=$password_err="";

    if(isset($_POST["kayit"]))
    {

        if(empty($_POST["kullaniciadi"])){
            $username_err="Kullanıcı adı boş geçilemez.";
        }
        else if(strlen($_POST["kullaniciadi"])<6){
            $username_err="Kullanıcı adı en az 6 karakterden oluşmalıdır.";
        }
        else if (!preg_match('/^[a-z\d_]{5,20}$/i', $_POST["kullaniciadi"])) {
            $username_err="Kullanıcı adı büyük küçük harf ve rakam içermelidir.";
        } 
        else{
            $username=$_POST["kullaniciadi"];
        }
        
        if(empty($_POST["email"])){
            $email_err="Email boş geçilemez.";
        }
        else if(!filter_var($_POST["email"],FILTER_VALIDATE_EMAIL)){
            $email_err="Geçersiz email formatı.";
        }
        else{
            $email=$_POST["email"];
        }

        if(empty($_POST["parola"])){
            $password_err="Parola boş geçilemez.";
        }
        else{
            $password=($_POST["parola"]);
        }



        $name=$_POST["kullaniciadi"];
        $email=$_POST["email"];
        $password=password_hash($_POST["parola"],PASSWORD_DEFAULT); 
        $usertype=$_POST["user_type"];
        $ekle="INSERT INTO kullanicilar (kullanici_adi,email,parola,kullanici_tipi) VALUES ('$name','$email','$password','$usertype')";
        $calistirekle=mysqli_query($baglanti,$ekle);
        if ($calistirekle) {
            echo '<div class="alert alert-success" role="alert">
            Kayıt başarılı bir şekilde eklendi!
        </div>';
        }
        else{
            echo '<div class="alert alert-danger" role="alert">
            Kayıt eklenirken bir hata oluştu!
        </div>';
        }
        mysqli_close($baglanti);
    }
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sınav Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        h1{
            text-align:center;
        }     
        .login{
            padding:60px;
        }   
        .card{
            padding:60px;
        }
        
    </style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <div class="login">
    <h1>Hoşgeldiniz</h1><br>
    <h2>Kayıt Olun</h2>
        <div class="card">
            <form action="kayit.php" method="POST">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Kullanıcı Adı</label>
                    <input type="text" class="form-control" name="kullaniciadi" id="exampleInputEmail1">
                    <div class="invalid-feedback">
                        <?php
                        echo $username_err;
                        ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" id="exampleInputEmail1">
                    <div class="invalid-feedback">
                        HATA
                    </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Şifre</label>
                    <input type="password" class="form-control" name="parola" id="exampleInputPassword1">
                    <div class="invalid-feedback">
                        HATA
                    </div>
                </div>
                <div class="mb-3">
                    <label for="type" class=form-label>Kullanıcı Tipi</label>
                    <select name="user_type">
                        <option value="ogrenci">Öğrenci</option>
                        <option value="ogretmen">Öğretmen</option>
                    </select>
                </div>
                <button type="submit" name="kayit" class="btn btn-primary">Kayıt Ol</button>
                <a href="login.php">Zaten üye misiniz? Giriş yapın.</a>
            </form>
            
        </div>
    </div>
</body>
</html>