<?php
include("baglanti.php");


if (isset($_POST['soru_metni']) && isset($_POST['sinav_adi']) && isset($_POST['secenek_a']) && isset($_POST['secenek_b']) &&
    isset($_POST['secenek_c']) && isset($_POST['secenek_d']) && isset($_POST['dogru_secenek'])) {
    
    $sorumetni = $_POST['soru_metni'];
    $sinavad = $_POST['sinav_adi'];
    $seceneka = $_POST['secenek_a'];
    $secenekb = $_POST['secenek_b'];
    $secenekc = $_POST['secenek_c'];
    $secenekd = $_POST['secenek_d'];
    $dogrusecenek = $_POST['dogru_secenek'];

    
    $sql = "INSERT INTO sorular (soru_metni, sinav_adi, secenek_a, secenek_b, secenek_c, secenek_d, dogru_secenek)
            VALUES ('$sorumetni', '$sinavad', '$seceneka', '$secenekb', '$secenekc', '$secenekd', '$dogrusecenek')";
    
    
    $sql_sinav = "SELECT sinav_adi FROM sinavlar WHERE sinav_adi = '$sinavad'";
    $sonuc_sinav = mysqli_query($baglanti, $sql_sinav);

    if (mysqli_num_rows($sonuc_sinav) > 0) {
        
        $sinavad = mysqli_fetch_assoc($sonuc_sinav)['sinav_adi'];
    } else {
        
        echo "Sınav adı mevcut değil.";
        return;
    }

    if ($baglanti->query($sql) === TRUE) {  
        echo "Soru başarıyla eklendi.";
    } else {
        echo "Hata: " . $sql . "<br>" . $baglanti->error;
    }
} 



$baglanti->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soru Ekle</title>
    <style>
        .btn{
            width: 170px;
            margin: 10px 0px;
        }
        ul{
    list-style-type: none;
    margin: 80px 30px 0px;
    padding: 0px;
    width: 200px;
    background-color: bisque;
    height: 70px;
    
}
li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
    background-color: bisque;
}
li {
    text-align: center;
    
}
.active {
  background-color: #04AA6D;
  color: white;
}
li a.active {
    background-color: #04AA6D;
    color: white;
}
  
li a:hover:not(.active) {
    background-color:lightgreen;
    color: white;
}   
        .form{
            margin:-100px 400px;
        }
    </style>
</head>
<body>
        <ul>
            <li><a class="main" href="maint.php">Ana Sayfa</a></li>
            <li><a class="addexam" href="addexam.php">Sınav Ekle</a></li>
            <li><a class="active" href="addque.php">Soru Ekle</a></li>
            <li><a class="delexam" href="delexam.php">Sınav Sil</a></li>
            <li><a class="exams" href="exams.php">Aktif Sınavlar</a></li>
            <li><a href="cikis.php">Çıkış Yap</a></li>
        </ul>
        <div class="form">
            <h2>Soru Ekleme Formu</h2>
        <form action="addque.php" method="post">

        <label for="soru_metni">Soru Metni:</label><br>
        <textarea id="soru_metni" name="soru_metni" rows="4" cols="50" required></textarea><br><br>

        <label for="sinav_adi">Sınav Adı:</label><br>
        <input type="text" id="sinav_adi" name="sinav_adi" required><br><br>
        
        <label for="secenek_a">A Şıkkı:</label><br>
        <input type="text" id="secenek_a" name="secenek_a" required><br><br>
        
        <label for="secenek_b">B Şıkkı:</label><br>
        <input type="text" id="secenek_b" name="secenek_b" required><br><br>
        
        <label for="secenek_c">C Şıkkı:</label><br>
        <input type="text" id="secenek_c" name="secenek_c" required><br><br>
        
        <label for="secenek_d">D Şıkkı:</label><br>
        <input type="text" id="secenek_d" name="secenek_d" required><br><br>
        
        <label for="dogru_secenek">Doğru Şık (A, B, C veya D):</label><br>
        <input type="text" id="dogru_secenek" name="dogru_secenek" maxlength="1" required><br><br>
        
        <input type="submit" class="btn" value="Soruyu Ekle">
        </form>
        </div>
</body>
</html>