<form action="" method="post">
    <?php
    date_default_timezone_set('Europe/Istanbul'); 
    include("baglanti.php");
    session_start();
    $currentDateTime = date('Y-m-d H:i:s'); 
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['sinav_adi'])) {
            $sinav_adi = $_POST['sinav_adi'];
            
            
            echo "<title>"."$sinav_adi"." Sınavı</title>";
            $sql = "SELECT * FROM sorular WHERE sinav_adi = '$sinav_adi'";
            $sonuc = $baglanti->query($sql);
            $zaman = "SELECT baslama_saati, bitis_saati FROM sinavlar WHERE sinav_adi = '$sinav_adi'";
            $sure =$baglanti->query($zaman);
            echo "Sınav : " . "$sinav_adi<br>";
            if ($sure->num_rows > 0) {
                
                while ($row = $sure->fetch_assoc()) {
                    $baslamaSaati=$row["baslama_saati"];
                    $bitisSaati=$row["bitis_saati"];
                    echo "Başlama Saati: " . $row["baslama_saati"] . "<br> Bitiş Saati: " . $row["bitis_saati"] . "<br>";
            } 
        }
        else {
                echo "Veritabanında kayıt bulunamadı.";
            }
            if ($sonuc->num_rows > 0) {
                while ($row = $sonuc->fetch_assoc()) {   
                    if ($currentDateTime < $baslamaSaati || $currentDateTime > $bitisSaati) {
                        echo "Sınav henüz başlamadı veya bitmiştir.";
                        echo "<?php
                        // Sayfa açıldığında oturumun sonlanması için
                        session_start();
                        
                        // 5 saniye sonra oturumu sonlandır
                        setTimeout(function(){
                            session_unset(); // Oturum değişkenlerini temizler
                            session_destroy(); // Oturumu tamamen sonlandırır
                        }, 5000); // 5000 milisaniye = 5 saniye
                        ?>";
                        continue;
                }
                    echo "<h3>Soru : " . $row['soru_metni'] . "</h3>";
                    echo "<input type='radio' name='secenek_" . $row['soru_id'] . "' value='A'>" . $row['secenek_a'] . "<br>";
                    echo "<input type='radio' name='secenek_" . $row['soru_id'] . "' value='B'>" . $row['secenek_b'] . "<br>";
                    echo "<input type='radio' name='secenek_" . $row['soru_id'] . "' value='C'>" . $row['secenek_c'] . "<br>";
                    echo "<input type='radio' name='secenek_" . $row['soru_id'] . "' value='D'>" . $row['secenek_d'] . "<br>";
                    echo "<input type='hidden' name='soru_id_" . $row['soru_id'] . "' value='" . $row['soru_id'] . "'>";
                    echo "<hr>";
                } 
                echo "<input type='submit' value='Cevapları Gönder'>";
                echo "<input type='hidden' name='sinav_adi' value='$sinav_adi'>";
                
                foreach ($_POST as $key => $value) {
                    if (strpos($key, 'secenek_') === 0) {
                        $soru_id = substr($key, strlen('secenek_'));
                        $ogrenci_cevabi = $value;

                        $gonder = "INSERT INTO cevaplar (sinav_adi, soru_id, ogrenci_cevabi) VALUES ('$sinav_adi', $soru_id, '$ogrenci_cevabi');";
                        $baglanti->query($gonder);
                    }
                    
                }
                

                
            } 
            else
                {
                echo "Seçilen sınav için soru bulunamadı.";
                }
        } 
        else
            {
            echo "Sınav adı alınamadı.";
            }
    }
    ?>
</form>
