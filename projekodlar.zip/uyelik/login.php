<?php
    include("baglanti.php");
    $username_err=$password_err="";

    if(isset($_POST["giris"]))
    {

        if(empty($_POST["kullaniciadi"])){
            $username_err="Kullanıcı adı boş geçilemez.";
        }
        else{
            $username=$_POST["kullaniciadi"];
        }
        if(empty($_POST["parola"])){
            $password_err="Parola boş geçilemez.";
        }
        else{
            $password=$_POST["parola"];
        }
        $usertype=$_POST["user_type"];
        if(isset($username)&&($password)&&($usertype)){

            $secim="SELECT * FROM kullanicilar WHERE kullanici_adi='$username'";
            $calistir=mysqli_query($baglanti,$secim);
            $kayit_sayisi=mysqli_num_rows($calistir);
            if($kayit_sayisi>0){
                $ilgili_kayit=mysqli_fetch_assoc($calistir);
                $sifre=$ilgili_kayit["parola"];
                $tip=$ilgili_kayit["kullanici_tipi"];
                if(password_verify($password,$sifre))
                {
                    if($usertype==$tip){
                        if($usertype=="ogrenci"){
                            session_start();
                        $_SESSION["kullanici_adi"]=$ilgili_kayit["kullanici_adi"];
                        $_SESSION["kullanici_tipi"]=$ilgili_kayit["kullanici_tipi"];
                        header("location:mains.php");
                        }
                        else{
                            session_start();
                        $_SESSION["kullanici_adi"]=$ilgili_kayit["kullanici_adi"];
                        $_SESSION["kullanici_tipi"]=$ilgili_kayit["kullanici_tipi"];
                        header("location:maint.php");
                        }
                    }
                    else{
                        echo '<div class="alert alert-danger" role="alert">
                        Kullanıcı Tipi Yanlış
                       </div>';
                    }
                    
                }
                else{
                    
                    echo '<div class="alert alert-danger" role="alert">
                     Parola Yanlış
                    </div>';
                }
            }
            else{
                echo '<div class="alert alert-danger" role="alert">
                    Kullanıcı Adı Yanlış
                    </div>';
            }

            mysqli_close($baglanti);
        }
        


        
    }
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sınav Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        h1{
            text-align:center;
        }     
        .login{
            padding:60px;
        }   
        .card{
            padding:60px;
        }
        
    </style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <div class="login">
        <h1>Hoşgeldiniz</h1><br>
        <h2>Giriş Yapın</h2>
        <div class="card">
            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Kullanıcı Adı</label>
                    <input type="text" class="form-control is-invalid" name="kullaniciadi" id="exampleInputEmail1">
                    <div class="invalid-feedback">
                        <?php
                        echo $username_err;
                        ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Şifre</label>
                    <input type="password" class="form-control is-invalid" name="parola" id="exampleInputPassword1">
                    <div class="invalid-feedback">
                        <?php
                            echo $password_err;
                        ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="type" class=form-label>Kullanıcı Tipi</label>
                    <select name="user_type">
                        <option value="ogrenci">öğrenci</option>
                        <option value="ogretmen">öğretmen</option>
                    </select>
                </div>
                <button type="submit" name="giris" class="btn btn-primary">Giriş Yap</button>
            </form>
        </div>
    </div>
</body>
</html>